/********************************************************************************
** Form generated from reading UI file 'cnn_qt.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CNN_QT_H
#define UI_CNN_QT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_cnn_qtClass
{
public:
    QWidget *centralWidget;
    QTextBrowser *textBrowser;
    QTextBrowser *textBrowser_2;
    QPushButton *pushButton;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *cnn_qtClass)
    {
        if (cnn_qtClass->objectName().isEmpty())
            cnn_qtClass->setObjectName(QStringLiteral("cnn_qtClass"));
        cnn_qtClass->resize(993, 858);
        centralWidget = new QWidget(cnn_qtClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        textBrowser = new QTextBrowser(centralWidget);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));
        textBrowser->setGeometry(QRect(20, 10, 781, 291));
        textBrowser_2 = new QTextBrowser(centralWidget);
        textBrowser_2->setObjectName(QStringLiteral("textBrowser_2"));
        textBrowser_2->setGeometry(QRect(20, 300, 781, 531));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(550, 50, 161, 41));
        cnn_qtClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(cnn_qtClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 993, 31));
        cnn_qtClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(cnn_qtClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        cnn_qtClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(cnn_qtClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        cnn_qtClass->setStatusBar(statusBar);

        retranslateUi(cnn_qtClass);

        QMetaObject::connectSlotsByName(cnn_qtClass);
    } // setupUi

    void retranslateUi(QMainWindow *cnn_qtClass)
    {
        cnn_qtClass->setWindowTitle(QApplication::translate("cnn_qtClass", "cnn_qt", 0));
        textBrowser->setHtml(QApplication::translate("cnn_qtClass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/cnn_qt/hello_world/Brown-Logo.001.jpg\" /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-weight:600;\">Welcome to ENGN 2912B Final Project</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-weight:600;\">Convolutional Neural Network</span></p>\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px"
                        "; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:10pt;\">Wenzhe Chen, Zhenhui Liu, Yu Jiang</span></p></body></html>", 0));
        textBrowser_2->setHtml(QApplication::translate("cnn_qtClass", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><img src=\":/cnn_qt/hello_world/1800px-LantingXu.jpg\" /></p></body></html>", 0));
        pushButton->setText(QApplication::translate("cnn_qtClass", "Program Quit", 0));
    } // retranslateUi

};

namespace Ui {
    class cnn_qtClass: public Ui_cnn_qtClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CNN_QT_H
