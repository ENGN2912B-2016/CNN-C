#ifndef CNN_QT_H
#define CNN_QT_H

#include <QtWidgets/QMainWindow>
#include "ui_cnn_qt.h"

class cnn_qt : public QMainWindow
{
	Q_OBJECT

public:
	cnn_qt(QWidget *parent = 0);
	~cnn_qt();

private:
	Ui::cnn_qtClass ui;
	private slots:
	void exit();
};

#endif // CNN_QT_H
