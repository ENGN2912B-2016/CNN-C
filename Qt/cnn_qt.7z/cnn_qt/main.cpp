#include "cnn_qt.h"
#include <QtWidgets/QApplication>
#include <QLabel>
#include "qpushbutton.h"

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	cnn_qt w;
	w.show();
	char* t = "  Show the result of CNN result in Character regonization:  \n\n";

	QLabel y(t);
	y.show();

	return a.exec();
}
