#include "cnn_qt.h"

cnn_qt::cnn_qt(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
	connect(ui.pushButton, SIGNAL(clicked()), this, SLOT(exit()));
}

cnn_qt::~cnn_qt()
{

}

void cnn_qt::exit()
{
	QApplication::exit();
}